# IPL-Dataset-Analysis-2008-2020
The complete analysis of IPL 2008-2020
